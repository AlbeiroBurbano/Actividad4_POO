package Personas;

public class persona {
  String nombre;
  String apellido;
  String telefono;
  String direccion;

  public persona(String nombre,String apellido, String telefono, String direccion){
      this.nombre=nombre;
      this.apellido=apellido;
      this.telefono=telefono;
      this.direccion=direccion;
  }
}
