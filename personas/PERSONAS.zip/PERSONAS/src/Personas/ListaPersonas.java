package Personas;

public class ListaPersonas {
    public void anadirPersona(persona p) {
    }

    public void eliminarPersona(int indice) {
    }

    public void borrarlist() {
    }
}
